/* MGA Quality Sentinel - background.js (v1.4.3)
   Enterprise Chromium Extension Service Worker */

chrome.runtime.onInstalled.addListener(() => {
  try {
    if (chrome.sidePanel?.setPanelBehavior) {
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
    }
  } catch (e) {}
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'QC_OPEN_DASHBOARD') {
    const dashboardUrl = chrome.runtime.getURL('index.html');
    chrome.tabs.create({ url: dashboardUrl });
    sendResponse({ ok: true, url: dashboardUrl });
    return true;
  }
  return true;
});
