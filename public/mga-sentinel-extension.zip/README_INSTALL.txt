========================================================================
MGA Quality Sentinel - Chrome & Microsoft Edge Installation Guide
========================================================================

COMPATIBILITY:
- Google Chrome (Version 114+)
- Microsoft Edge (Version 114+)
Manifest V3 architecture. No cloud database, no server, 100% Local-First.

QUICK INSTALLATION (Takes 30 seconds):
------------------------------------------------------------------------
1. Extract this entire zip archive to a local folder on your computer.
   (e.g., C:\MGA_Quality_Sentinel or ~/Documents/MGA_Quality_Sentinel)

2. Open your Chromium browser:
   - For Google Chrome: Navigate to  chrome://extensions
   - For Microsoft Edge: Navigate to edge://extensions

3. Turn ON "Developer mode" toggle (usually at top right).

4. Click the "Load unpacked" button (top left).

5. Select the extracted folder containing "manifest.json".

6. Done! The MGA Quality Sentinel icon will appear in your browser toolbar.
   Click the puzzle icon to Pin it to your toolbar.

HOW TO OPEN THE FULL DASHBOARD:
------------------------------------------------------------------------
Method 1: Click the MGA extension icon in your toolbar, then click:
          "📊 Open Full Quality Dashboard ↗"
Method 2: Open a new tab and navigate to:
          chrome-extension://<EXTENSION_ID>/index.html
Method 3: Right-click page -> MGA Quality Sentinel Side Panel -> Open Full Dashboard.

Inside the Extension, Search & Scan has full native permissions to open
Walmart, Amazon, and Target tabs, scan ratings and reviews, and monitor trends!
